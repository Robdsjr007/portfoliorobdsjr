$(document).ready(function(){
    $('#btnEsconder').click(function(){
        $('h1').show();
    })
    $('#btnMostrar').click(function(){
        $('h1').hide();
    })
    $('#btnReverso').click(function(){
        $('h1').toggle()
        .css('color','red')
        .css('backgound-color','black')
    })
    $('#btnReverso').click(function(){
        $('#aula').css('color','blue');
        $('h1').css('backgound-color','black')
    })
    $('#btnMensagem').click(function(){
        $('#mensagem').text("Seja Bem-Vindo(a)!");
        $('#mensagem').css("font-size","42px");
    })
    $('#link1').click(function(){
        $('#img01').show()
        $('#img02').hide()
        $('#img03').hide()
    })
    $('#link2').click(function(){
        $('#img02').show()
        $('#img01').hide()
        $('#img03').hide()
    })
    $('#link3').click(function(){
        $('#img03').show()
        $('#img01').hide()
        $('#img02').hide()
    })


})