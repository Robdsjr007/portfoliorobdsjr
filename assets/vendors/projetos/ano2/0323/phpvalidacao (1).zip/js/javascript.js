function validar(){
    var email = frmLogin.email.value;
    var senha = frmLogin.senha.value;

    if (email == "") {
        alert('Por favor preencha corretamente!');
        frmLogin.email.focus();
        return false;
    }

    if (senha == "") {
        alert('Por favor preencha corretamente!');
        frmLogin.senha.focus();
        return false;
    }

}