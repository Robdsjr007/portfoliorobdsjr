<?php

    require "inicio.html";
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $email = "macaquinho@gmail.com";
    $senha = 123;

    if ($email == $_POST['email'] && $senha == $_POST['senha']):
        require "cardsemerro.html";
    elseif ($email == $_POST['email'] && $senha != $_POST['senha']):
        require "cardsenha.html";
    elseif ($email != $_POST['email'] && $senha == $_POST['senha']):
        require "cardemail.html";
    elseif ($email != $_POST['email'] && $senha != $_POST['senha']):
        require "carderro.html";           
    endif;

    require "fim.html";  

?>