<?php

    require "inicio.html";
    require "form.html";
    require "fim.html";
     
?>